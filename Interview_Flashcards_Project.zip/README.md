# Interview Prep Flashcards
Deployed using Firebase Hosting

**Live Link:** https://interview-flashcards12.web.app  
**Firebase Project ID:** interview-flashcards12  
**Student:** Temesgen Gadore  
**Class:** CSS205 (Web Development)  
**Instructor:** Prof. Dawn Duerre  

## Description
A web app that allows users to create and study flashcards for interview preparation.  
Built with HTML, CSS, and JavaScript, and hosted on Firebase.

## Files
- `index.html` – Main interface
- `app.js` – Application logic
- `firebase-config.js` – Firebase setup
- `styles.css` – Styling
